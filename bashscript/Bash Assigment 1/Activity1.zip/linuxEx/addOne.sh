echo please enter num
read x
echo $((${x}+1))
