cat /etc/passwd
