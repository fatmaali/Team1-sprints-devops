echo $USER
