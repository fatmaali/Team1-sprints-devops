#! /bin/bash
cd ${1}
