echo 'please enter your username'
read name
echo 'hello' $name
