echo "hello "$1
