x=5
eval "./sc2.1.sh ${x}"
