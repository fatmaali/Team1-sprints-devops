echo "$*" > f.txt 
sed -i "s/ /\n/g" f.txt
sort  -rn f.txt
rm f.txt

