sort -t : -k 3 -n /etc/passwd
