 sort -t : -k 1  /etc/passwd
